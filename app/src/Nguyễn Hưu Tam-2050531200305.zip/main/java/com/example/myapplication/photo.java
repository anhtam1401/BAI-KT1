package com.example.myapplication;

public class photo {
    private int resouId;

    public photo(int resouId) {
        this.resouId = resouId;
    }

    public int getResouId() {
        return resouId;
    }

    public void setResouId(int resouId) {
        this.resouId = resouId;
    }
}
