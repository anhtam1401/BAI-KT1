package com.example.myapplication;

public class User {
    public String name, email, pass;

    public User(String email, String pass){

    }
    public User(String name, String email, String pass){
        this.email=email;
        this.name=name;
        this.pass = pass;

    }
}

